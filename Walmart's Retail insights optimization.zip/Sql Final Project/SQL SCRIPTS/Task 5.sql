Task 5: Most Popular Payment Method by City
WITH payment_counts AS (SELECT City,Payment,COUNT(*) AS payment_count
FROM walmart_data
GROUP BY City, Payment),
ranked_payments AS (SELECT *,
RANK() OVER (PARTITION BY City ORDER BY payment_count DESC) AS Rnk
FROM payment_counts
)
SELECT City,Payment AS Most_Popular_Payment_Method,payment_count,RNK
FROM ranked_payments
WHERE RNK = 1;
