Task 2: Finding the Most Profitable Product Line for Each Branch.
WITH product_profit AS (SELECT Branch,`Product line`,SUM(`gross income` - cogs) AS PROFIT_MARGIN
    FROM walmart_data
    GROUP BY Branch, `Product line`),
Ranked_Product AS (Select Branch,
        `Product line`,
        PROFIT_MARGIN,
        RANK() OVER (PARTITION BY Branch ORDER BY PROFIT_MARGIN DESC) AS RNK
    FROM product_profit)
    SELECT Branch,`Product line`,PROFIT_MARGIN,RNK
FROM ranked_product
Where RNK=1;
