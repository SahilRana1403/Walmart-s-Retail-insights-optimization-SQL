Task 6: Monthly Sales Distribution by Gender (
SELECT DATE_FORMAT(STR_TO_DATE(Date, '%d-%m-%Y'), '%m') AS sales_month,Gender,SUM(Total) AS total_sales
FROM walmart_data
GROUP BY sales_month, Gender
ORDER BY sales_month, Gender;