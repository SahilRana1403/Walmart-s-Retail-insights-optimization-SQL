Task 7: Best Product Line by 'Customer Type' 
Walmart wants to know which product lines are preferred by different customer types(Member vs. Normal)
WITH product_sales AS (
SELECT `Customer type`,`Product line`,SUM(Total) AS total_sales
FROM walmart_data
GROUP BY `Customer type`, `Product line`),
ranked_products AS (
SELECT *,
RANK()
OVER (PARTITION BY `Customer type` ORDER BY Total_sales DESC) AS RNK
FROM product_sales)
SELECT `Customer type`,`Product line`,round(Total_sales) as Total_sales
FROM ranked_products
WHERE RNK = 1;
