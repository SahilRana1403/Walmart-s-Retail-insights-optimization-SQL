Task 10: Analyzing Sales Trends by Day of the Week
SELECT DAYNAME(STR_TO_DATE(Date, '%d-%m-%Y')) AS week_day,SUM(Total) AS total_sales
FROM walmart_data
GROUP BY week_day
ORDER BY total_sales DESC;
