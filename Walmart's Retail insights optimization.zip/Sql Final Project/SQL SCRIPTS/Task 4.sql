task 4 Detecting Anomalies in Sales Transactions 
WITH ProductStat AS (
SELECT `Product line`,AVG(Total) AS Average_Total
FROM walmart_data
GROUP BY `Product line`)
SELECT w.`Invoice ID`,w.`Product line`,w.Total,p.Average_Total,
CASE
WHEN w.Total > p.Average_Total THEN 'High Anomaly'
WHEN w.Total < p.Average_Total THEN 'Low Anomaly'
ELSE 'Normal'
END AS Anomaly
FROM walmart_data w
JOIN ProductStat p ON w.`Product line` = p.`Product line`;
 