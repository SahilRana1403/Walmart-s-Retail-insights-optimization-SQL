Task 9: Finding Top 5 Customers by Sales Volume
SELECT `Customer ID`,SUM(round(Total)) AS total_sales
FROM walmart_data
GROUP BY `Customer ID`
ORDER BY 'Customer ID' DESC
LIMIT 5;
