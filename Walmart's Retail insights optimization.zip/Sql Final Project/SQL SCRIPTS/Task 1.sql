Task 1: Identifying the Top Branch by Sales Growth Rate
WITH monthly_sales AS (SELECT Branch,DATE_FORMAT(STR_TO_DATE(Date, '%d-%m-%Y'), '%Y-%m') AS sales_month,
SUM(Total) AS monthly_total
FROM walmart_data
GROUP BY Branch, sales_month
),
growth_calculation AS (
SELECT Branch,sales_month,monthly_total,
LAG(monthly_total)
OVER (PARTITION BY Branch ORDER BY sales_month) AS prev_month_total
FROM monthly_sales
),
growth_rate AS (SELECT Branch,sales_month,monthly_total,prev_month_total,
CASE 
WHEN prev_month_total IS NOT NULL AND prev_month_total > 0 THEN (monthly_total - prev_month_total) / prev_month_total
ELSE NULL
END AS growth_rate
FROM growth_calculation
)
SELECT Branch,AVG(growth_rate) AS avg_growth_rate
FROM growth_rate
WHERE growth_rate IS NOT NULL
GROUP BY Branch
ORDER BY avg_growth_rate DESC
LIMIT 3;
