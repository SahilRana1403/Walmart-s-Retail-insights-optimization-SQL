Task 3: Analyzing Customer Segmentation Based on Spending 
WITH customer_spending AS (
    SELECT `Customer ID`,SUM(Total) AS total_spent
    FROM walmart_data
    GROUP BY `Customer ID`) 
    SELECT `Customer ID`,round(total_spent) as total_spent,
case
when total_spent<20000 then 'Low'
when total_spent  between 20000 and 23000 then 'Medium' 
else 'High'
end as Customer_Segmentation
from customer_spending 
order by 'Customer ID' asc;